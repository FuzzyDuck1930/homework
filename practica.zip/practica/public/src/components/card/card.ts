class card extends HTMLElement{

    constructor(){
        super();
        this.attachShadow({mode:"open"})
    }

    connectedCallback(){
        this.render();
    }

    static get observedAttributes(){
        return[];
    }

    changedAttributeCallback(propName,oldValue,newValue){
        this[propName] = newValue;
    }

    render(){
        this.shadowRoot?.innerHTML =  `
        <section></section>
        `
    }
}

customElements.define("my-card",card);
export default card
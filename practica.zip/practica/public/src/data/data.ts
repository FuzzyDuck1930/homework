const data = [
    {
      name: "John Smith",
      id: 1001,
      gender: "Male",
      age: 35,
    },
    {
      name: "Sarah Johnson",
      id: 1002,
      gender: "Female",
      age: 28,
    },
    {
      name: "Michael Brown",
      id: 1003,
      gender: "Male",
      age: 42,
    },
    {
      name: "Emily Davis",
      id: 1004,
      gender: "Female",
      age: 31,
    },
    {
      name: "David Lee",
      id: 1005,
      gender: "Male",
      age: 40,
    },
    {
      name: "Jessica Clark",
      id: 1006,
      gender: "Female",
      age: 25,
    },
    {
      name: "William Wilson",
      id: 1007,
      gender: "Male",
      age: 29,
    },
    {
      name: "Olivia White",
      id: 1008,
      gender: "Female",
      age: 34,
    },
    {
      name: "James Taylor",
      id: 1009,
      gender: "Male",
      age: 37,
    },
    {
      name: "Sophia Adams",
      id: 1010,
      gender: "Female",
      age: 27,
    },
  ];

  export default data